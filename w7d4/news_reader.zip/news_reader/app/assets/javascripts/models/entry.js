NewsReader.Models.Entry = Backbone.Model.extend({

});
